import React, { useState } from 'react';
import Header from './components/Header';
import ProductGrid from './components/ProductGrid';
import Footer from './components/Footer';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay, EffectFade } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/effect-fade';

// Hero slides data
const heroSlides = [
  {
    image: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=2000",
    title: "Новая Коллекция",
    subtitle: "Откройте для себя последние тенденции моды"
  },
  {
    image: "https://images.unsplash.com/photo-1445205170230-053b83016050?auto=format&fit=crop&w=2000",
    title: "Весенняя Коллекция",
    subtitle: "Свежие образы для нового сезона"
  },
  {
    image: "https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=2000",
    title: "Премиум Качество",
    subtitle: "Эксклюзивные модели для вашего гардероба"
  }
];

// Sample product data
const products = {
  featured: [
    {
      id: 1,
      name: "Худи",
      price: 33,
      image: "https://i.pinimg.com/736x/81/c4/c3/81c4c30d82ea016dafac5a17db0adb60.jpg",
      category: "featured"
    },
    {
      id: 2,
      name: "Пижама от ZARA",
      price: 79,
      image: "https://i.pinimg.com/736x/01/b5/29/01b5294336b116408bd9b868bcedc4c8.jpg",
      category: "featured"
    },
    {
      id: 3,
      name: "Свитер от POLO",
      price: 56,
      image: "https://i.pinimg.com/736x/eb/52/e5/eb52e58c9d788e86fb0910020c533835.jpg",
      category: "featured"
    },
    {
      id: 4,
      name: "Базовая белая футболка",
      price: 49,
      image: "https://i.pinimg.com/736x/3e/75/84/3e75846c729912eaa1aa802a32a88978.jpg",
      category: "featured"
    },
    {
      id: 5,
      name: "Свитер от POLO",
      price: 56,
      image: "https://i.pinimg.com/736x/84/b2/ab/84b2abab43f6a9dadf40a9c6d77e31d8.jpg",
      category: "featured"
    },
    {
      id: 6,
      name: "Свитер от ZARA",
      price: 65,
      image: "https://i.pinimg.com/736x/33/29/00/33290089b8fcf1b3a05fbadf897794c4.jpg",
      category: "featured"
    },
    {
      id: 7,
      name: "Футболка от AMI",
      price: 28,
      image: "https://i.pinimg.com/736x/ba/89/04/ba89047666a4dba87b6174d3b09bf8a4.jpg",
      category: "featured"
    },
    {
      id: 8,
      name: "Air Force",
      price: 50,
      image: "https://i.pinimg.com/736x/5a/e7/8b/5ae78bb217e381c28da5b02262cf9426.jpg",
      category: "featured"
    },
  ],
  women: [
    {
      id: 9,
      name: "Легкие штаны от ZARA",
      price: 69,
      image: "https://i.pinimg.com/736x/ae/31/7c/ae317cab8867465940b1dd4b78a314e3.jpg",
      category: "women"
    },
    {
      id: 10,
      name: "Зип худи",
      price: 56,
      image: "https://i.pinimg.com/736x/e7/c7/a7/e7c7a7e9f4713bc13fd04619ee6b4d3e.jpg",
      category: "featured"
    },
    {
      id: 11,
      name: "Боди",
      price: 73,
      image: "https://i.pinimg.com/736x/11/8e/1b/118e1b6c16c169406eabffefc06d5a3d.jpg",
      category: "featured"
    },
    {
      id: 12,
      name: "Летние шорты от ZARA",
      price: 49,
      image: "https://i.pinimg.com/736x/8f/c8/b1/8fc8b12b74bfa3100ea3745b658835e8.jpg",
      category: "women"
    },
  ],
  men: [
    {
      id: 13,
      name: "Бомбер",
      price: 79,
      image: "https://i.pinimg.com/736x/f6/d4/dc/f6d4dcbb028861c79c831a370e59812e.jpg",
      category: "men"
    },
    {
      id: 14,
      name: "Бомбер",
      price: 99,
      image: "https://fashionedway.com/cdn/shop/files/2803_9_1667401357.webp?v=1741041883&width=713",
      category: "man"
    },
    {
      id: 15,
      name: "Свитер от LACOSTE",
      price: 79,
      image: "https://i.pinimg.com/736x/c3/45/ab/c345ab8ddd0fa55dd9b838fd5dd1d024.jpg",
      category: "men"
    },
    {
      id: 16,
      name: "Свитер",
      price: 73,
      image: "https://i.pinimg.com/736x/07/3f/da/073fda1bec82e42800dd7a3ad9196bee.jpg",
      category: "men"
    },
  ],
  footwear: [
    {
      id: 17,
      name: "Nike Court Royale 2 Nn",
      price: 69,
      image: "https://i.pinimg.com/736x/83/8e/9c/838e9c1cee14c9d4a95bba66b61e3d29.jpg",
      category: "footwear"
    },
    {
      id: 18,
      name: "Nike Just Do It",
      price: 89,
      image: "https://i.pinimg.com/736x/33/58/bb/3358bb3fa3b8a53d620b8fffdffb69f2.jpg",
      category: "footwear"
    },
  ],
  accessories: [
    {
      id: 19,
      name: "Сумка через плечо Dickies",
      price: 49,
      image: "https://i.pinimg.com/736x/95/a0/3f/95a03f32602448ccba7e54df6334bed7.jpg",
      category: "accessories"
    },
    {
      id: 20,
      name: "Серебряные серьги",
      price: 14,
      image: "https://i.pinimg.com/736x/a1/fa/3c/a1fa3c42a59a9b1cfef831d8f458311c.jpg",
      category: "accessories"
    },
  ]
};

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section with Slideshow */}
      <section className="relative h-screen">
        <Swiper
          modules={[Navigation, Pagination, Autoplay, EffectFade]}
          effect="fade"
          navigation
          pagination={{ clickable: true }}
          autoplay={{
            delay: 5000,
            disableOnInteraction: false,
          }}
          loop={true}
          className="h-full"
        >
          {heroSlides.map((slide, index) => (
            <SwiperSlide key={index}>
              <div className="relative h-full">
                <img
                  src={slide.image}
                  alt={slide.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                  <div className="text-center text-white">
                    <h1 className="text-5xl md:text-6xl font-bold mb-4">{slide.title}</h1>
                    <p className="text-xl mb-8">{slide.subtitle}</p>
                    <a
                      href="#featured"
                      className="bg-white text-black px-8 py-3 rounded-full hover:bg-gray-100 transition-colors"
                    >
                      Купить Сейчас
                    </a>
                  </div>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </section>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Featured Products */}
        <section id="featured" className="pt-24">
          <ProductGrid title="Избранные Коллекции" products={products.featured} />
        </section>

        {/* Women's Section */}
        <section id="women">
          <ProductGrid title="Женская Одежда" products={products.women} />
        </section>

        {/* Men's Section */}
        <section id="men">
          <ProductGrid title="Мужская Одежда" products={products.men} />
        </section>

        {/* Footwear Section */}
        <section id="footwear">
          <ProductGrid title="Обувь" products={products.footwear} />
        </section>

        {/* Accessories Section */}
        <section id="accessories">
          <ProductGrid title="Аксессуары" products={products.accessories} />
        </section>

        {/* Brands Section */}
        <section className="py-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Наши Бренды</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center justify-items-center opacity-60">
            <img src="https://i.pinimg.com/736x/c0/8b/bb/c08bbbd32ac78859882278ffdf236e89.jpg" 
              alt="ZARA" className="h-13 object-contain" />
            <img src="https://i.pinimg.com/736x/29/f6/49/29f6492fa8560ea4c74dcb474d1cc9cf.jpg"
              alt="Lacoste" className="h-13 object-contain" />
            <img src="https://i.pinimg.com/736x/18/31/a3/1831a3eb3e33f3d2bf0f03e1e08fc868.jpg"
              alt="Polo" className="h-13 object-contain" />
            <img src="https://i.pinimg.com/736x/3f/3b/c1/3f3bc1d7de5c4c2996169439d8db2398.jpg" 
              alt="Nike" className="h-13 object-contain" />
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

export default App;