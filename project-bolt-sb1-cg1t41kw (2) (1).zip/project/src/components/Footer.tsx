import React from 'react';
import { Facebook, Twitter, Instagram, CreditCard, Truck, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">О Нас</h3>
            <p className="text-gray-400">
              Marlone Collection предлагает премиальную моду для современного человека. Качество встречается со стилем в каждом изделии.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Контакты</h3>
            <ul className="space-y-2 text-gray-400">
              <li>Китай, г. Шанхай</li>
              <li>Кыргызстан, г. Бишкек</li>
              <li>Тел: +195 16387625</li>
              <li>Email: akasymowv@gmail.com</li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Социальные сети</h3>
            <div className="flex space-x-4">
              <a 
                href="https://www.instagram.com/marlone_collection?igsh=dmo1bThlaGZ2cnl5" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="hover:text-gray-400"
              >
                <Instagram className="w-6 h-6" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Подписка на новости</h3>
            <form className="space-y-2">
              <input
                type="email"
                placeholder="Ваш email"
                className="w-full px-4 py-2 rounded bg-gray-800 text-white"
              />
              <button className="w-full bg-white text-black py-2 rounded hover:bg-gray-200">
                Подписаться
              </button>
            </form>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-800">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="flex items-center space-x-4">
              <CreditCard className="w-6 h-6" />
              <span>Безопасные платежи</span>
              <Truck className="w-6 h-6 ml-4" />
              <span>Быстрая доставка</span>
            </div>
            <p className="text-gray-400">© 2024 Marlone Collection. Все права защищены.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}