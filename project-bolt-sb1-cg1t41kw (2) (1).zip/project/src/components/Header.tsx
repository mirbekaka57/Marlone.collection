import React, { useState } from 'react';
import { Search, ShoppingBag, Menu, X } from 'lucide-react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [cartCount] = useState(0);

  const scrollToBottom = () => {
    window.scrollTo({
      top: document.documentElement.scrollHeight,
      behavior: 'smooth'
    });
  };

  return (
    <header className="fixed top-0 left-0 right-0 bg-white z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <button 
            onClick={scrollToBottom}
            className="flex-shrink-0 font-serif text-2xl tracking-wider hover:opacity-75 transition-opacity"
          >
            MARLONE COLLECTION
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <a href="#featured" className="text-gray-700 hover:text-black">Избранное</a>
            <a href="#women" className="text-gray-700 hover:text-black">Женщинам</a>
            <a href="#men" className="text-gray-700 hover:text-black">Мужчинам</a>
            <a href="#footwear" className="text-gray-700 hover:text-black">Обувь</a>
            <a href="#accessories" className="text-gray-700 hover:text-black">Аксессуары</a>
          </nav>

          {/* Icons */}
          <div className="flex items-center space-x-4">
            <button className="p-2 hover:bg-gray-100 rounded-full">
              <Search className="w-5 h-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-full relative">
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute top-0 right-0 bg-black text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
            <button 
              className="md:hidden p-2 hover:bg-gray-100 rounded-full"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a href="#featured" className="block px-3 py-2 text-gray-700 hover:bg-gray-100">Избранное</a>
            <a href="#women" className="block px-3 py-2 text-gray-700 hover:bg-gray-100">Женщинам</a>
            <a href="#men" className="block px-3 py-2 text-gray-700 hover:bg-gray-100">Мужчинам</a>
            <a href="#footwear" className="block px-3 py-2 text-gray-700 hover:bg-gray-100">Обувь</a>
            <a href="#accessories" className="block px-3 py-2 text-gray-700 hover:bg-gray-100">Аксессуары</a>
          </div>
        </div>
      )}
    </header>
  );
}